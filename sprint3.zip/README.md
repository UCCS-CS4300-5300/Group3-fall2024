# Mountian Lion Movie Application

### Group 3
*  **Travis** Dittmanson
*  **Nathan** Engler
*  **Ashley** Judson 
*  **Kory** Mayberry 
*  **Bob** Kroleski
*  **Garrett** Smith

### HOW TO RUN THE PROGRAM
1. `start virtual environment`
2. `cd group3Project`
3. `python manage.py runserver`

### HOW TO START YOUR VIRTUAL ENVIRONMENT
For mac:
`source {NAME}/bin/activate`
For windows:
`.\{NAME}\Scripts\activate`

### HOW TO CREATE A VIRTUAL ENVIRONMENT
`python3 -m venv {NAME}`


